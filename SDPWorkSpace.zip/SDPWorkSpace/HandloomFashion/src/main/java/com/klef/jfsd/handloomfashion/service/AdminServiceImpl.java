package com.klef.jfsd.handloomfashion.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.handloomfashion.model.Admin;
import com.klef.jfsd.handloomfashion.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService
{

	@Autowired
	public AdminRepository adminrepository;
	@Override
	public Admin checkadminlogin(String uname, String upassword) 
	{
		
		return adminrepository.checkadminlogin(uname , upassword);
	}

}
