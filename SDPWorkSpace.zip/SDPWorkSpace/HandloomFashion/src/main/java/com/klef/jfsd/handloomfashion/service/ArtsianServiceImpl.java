package com.klef.jfsd.handloomfashion.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.handloomfashion.model.Artsian;
import com.klef.jfsd.handloomfashion.repository.ArtsianRepository;


@Service
public class ArtsianServiceImpl implements ArtsianService 
{
	@Autowired
	ArtsianRepository repository;

	@Override
	public String signup(Artsian a) {
		repository.save(a);
		return "Artsian added successfully";
	}

	@Override
	public Artsian login(String username, String password) {
		 return repository.findById(username)
	                .filter(a -> a.getPassword().equals(password))
	                .orElse(null);
	    }
	
}
