package com.klef.jfsd.handloomfashion.service;

import com.klef.jfsd.handloomfashion.model.Admin;

public interface AdminService 
{
 public Admin checkadminlogin(String uname , String upassword);
}
