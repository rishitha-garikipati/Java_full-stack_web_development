package com.klef.jfsd.handloomfashion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandloomFashionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandloomFashionApplication.class, args);
		
		System.out.println("project is running.....");
	}

}
