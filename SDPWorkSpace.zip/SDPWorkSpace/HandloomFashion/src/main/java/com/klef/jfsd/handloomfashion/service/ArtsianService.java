package com.klef.jfsd.handloomfashion.service;


import com.klef.jfsd.handloomfashion.model.Artsian;

public interface ArtsianService 
{
	public String signup (Artsian a);
	
	Artsian login(String username , String password);
}
