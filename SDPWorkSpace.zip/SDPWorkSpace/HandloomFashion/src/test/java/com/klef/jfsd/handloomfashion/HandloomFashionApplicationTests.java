package com.klef.jfsd.handloomfashion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandloomFashionApplicationTests {

	@Test
	void contextLoads() {
	}

}
